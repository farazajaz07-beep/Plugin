package dev.faraz.textchange;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextReplacementConfig;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class TextChangePlugin extends JavaPlugin implements Listener {
    private final List<Rule> rules = new ArrayList<>();

    private record Rule(String oldText, String newText) {}

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadRules();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("Loaded " + rules.size() + " text replacement rule(s).");
    }

    private void loadRules() {
        rules.clear();
        for (MapEntry entry : readConfigRules()) {
            if (!entry.oldText().isEmpty()) rules.add(new Rule(entry.oldText(), entry.newText()));
        }
    }

    private record MapEntry(String oldText, String newText) {}

    private List<MapEntry> readConfigRules() {
        List<MapEntry> result = new ArrayList<>();
        for (Object raw : getConfig().getList("rules", List.of())) {
            if (raw instanceof java.util.Map<?, ?> map) {
                Object old = map.get("old");
                Object replacement = map.get("new");
                if (old != null && replacement != null)
                    result.add(new MapEntry(String.valueOf(old), String.valueOf(replacement)));
            }
        }
        return result;
    }

    private void saveRules() {
        List<java.util.Map<String, String>> saved = new ArrayList<>();
        for (Rule rule : rules) {
            java.util.Map<String, String> row = new java.util.LinkedHashMap<>();
            row.put("old", rule.oldText());
            row.put("new", rule.newText());
            saved.add(row);
        }
        getConfig().set("rules", saved);
        saveConfig();
    }

    private String replacePlain(String input) {
        String result = input;
        for (Rule rule : rules) {
            result = result.replace(rule.oldText(), rule.newText());
        }
        return result;
    }

    private Component replaceComponent(Component input) {
        Component result = input;
        for (Rule rule : rules) {
            TextReplacementConfig config = TextReplacementConfig.builder()
                    .matchLiteral(rule.oldText())
                    .replacement(rule.newText())
                    .build();
            result = result.replaceText(config);
        }
        return result;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (event.joinMessage() != null) event.joinMessage(replaceComponent(event.joinMessage()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (event.quitMessage() != null) event.quitMessage(replaceComponent(event.quitMessage()));
    }

    @SuppressWarnings("deprecation")
    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        event.setMessage(replacePlain(event.getMessage()));
        String format = event.getFormat();
        // Apply rules to the configured legacy chat format too.
        event.setFormat(replacePlain(format));
    }

    @EventHandler
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player)) return;
        // Bukkit/Paper does not expose a safe general setter for an already-created
        // inventory's title. This handles visible item names and lore in opened GUIs.
        for (ItemStack item : event.getInventory().getContents()) {
            if (item == null || !item.hasItemMeta()) continue;
            ItemMeta meta = item.getItemMeta();
            if (meta == null) continue;
            if (meta.hasDisplayName()) meta.displayName(replaceComponent(meta.displayName()));
            if (meta.lore() != null) {
                List<Component> changed = new ArrayList<>();
                for (Component line : meta.lore()) changed.add(replaceComponent(line));
                meta.lore(changed);
            }
            item.setItemMeta(meta);
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("textchange.admin")) {
            sender.sendMessage("§cYou don't have permission.");
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
            if (rules.isEmpty()) sender.sendMessage("§eNo replacement rules configured.");
            for (int i = 0; i < rules.size(); i++) {
                Rule r = rules.get(i);
                sender.sendMessage("§e" + (i + 1) + ". §f" + r.oldText() + " §7→ §f" + r.newText());
            }
            return true;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            try {
                int index = Integer.parseInt(args[1]) - 1;
                if (index < 0 || index >= rules.size()) {
                    sender.sendMessage("§cInvalid rule number. Use /textchange list");
                    return true;
                }
                Rule removed = rules.remove(index);
                saveRules();
                sender.sendMessage("§aRemoved rule: §f" + removed.oldText() + " §7→ §f" + removed.newText());
            } catch (NumberFormatException ex) {
                sender.sendMessage("§cUse /textchange remove <number>");
            }
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("clear")) {
            rules.clear();
            saveRules();
            sender.sendMessage("§aAll replacement rules cleared.");
            return true;
        }
        if (args.length != 2) {
            sender.sendMessage("§eUsage: /textchange <old> <new>");
            sender.sendMessage("§e/textchange list | remove <number> | clear");
            sender.sendMessage("§7For phrases with spaces, use a short unique token or edit plugins/TextChange/config.yml.");
            return true;
        }
        if (args[0].isEmpty()) {
            sender.sendMessage("§cOld text cannot be empty.");
            return true;
        }
        rules.add(new Rule(args[0], args[1]));
        saveRules();
        sender.sendMessage("§aAdded persistent replacement: §f" + args[0] + " §7→ §f" + args[1]);
        return true;
    }
}
