# TextChange — Paper / Purpur / Leaf

A starter Java plugin project for Minecraft Java servers. It stores replacement rules in `plugins/TextChange/config.yml`.

## Commands
- `/textchange <old> <new>` — add a literal, case-sensitive replacement rule
- `/textchange list` — list rules
- `/textchange remove <number>` — remove a rule
- `/textchange clear` — remove all rules

Permission: `textchange.admin` (operators by default).

## Build
Requires Java 21 and Maven:
```bash
mvn package
```
Copy `target/textchange-1.0.0.jar` to the server's `plugins/` directory and restart.

## Important coverage limits
This is not a universal packet-level interceptor. It handles chat through Bukkit's legacy chat event, join/quit messages, and item display names/lore when an inventory opens. It does not automatically rewrite arbitrary plugin messages, GUI titles, scoreboard packets, tab headers/footers, action bars, titles, boss bars, signs, books, or packet-level text. Those require additional event hooks or a packet-interception layer and may conflict with plugins that own their own components.

Rules entered as command arguments are single words (e.g. `/textchange play.abc.xyz play.new.xyz`). For phrases with spaces, edit the `rules` list in `plugins/TextChange/config.yml`, then restart.
